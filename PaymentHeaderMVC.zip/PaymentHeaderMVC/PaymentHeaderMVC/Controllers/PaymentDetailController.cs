﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using PaymentHeaderMVC.Models;

namespace PaymentHeaderMVC.Controllers
{
    public class PaymentDetailController : Controller
    {
        public async Task<IActionResult> Index()
        {
            //Hosted web API REST Service base url  
            string Baseurl = "http://localhost:49602/";

            List<PaymentDetailModel> paymentDetailModel = new List<PaymentDetailModel>();
            using (var client = new HttpClient())
            {
                //Passing service base url  
                client.BaseAddress = new Uri(Baseurl);

                client.DefaultRequestHeaders.Clear();
                //Define request data format  
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                //Sending request to find web api REST service resource PaymentDetail using HttpClient  
                HttpResponseMessage Res = await client.GetAsync("api/PaymentDetail");

                //Checking the response is successful or not which is sent using HttpClient  
                if (Res.IsSuccessStatusCode)
                {
                    //Storing the response details recieved from web api   
                    var Payment_Detail = Res.Content.ReadAsStringAsync().Result;

                    //Deserializing the response recieved from web api and storing into the Employee list  
                    paymentDetailModel = JsonConvert.DeserializeObject<List<PaymentDetailModel>>(Payment_Detail);

                }
                //returning the employee list to view  
                return View(paymentDetailModel);
            }
        }
    }
}