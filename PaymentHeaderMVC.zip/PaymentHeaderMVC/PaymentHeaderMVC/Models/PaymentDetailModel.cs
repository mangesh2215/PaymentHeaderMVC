﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PaymentHeaderMVC.Models
{
    public class PaymentDetailModel
    {
        public int PMId { get; set; }
        public string CardOwnerName { get; set; }
        public string CardNumber { get; set; }
        public string ExpirationDate { get; set; }
        public string CVVNumber { get; set; }
        public string CompanyName { get; set; }
    }
}
